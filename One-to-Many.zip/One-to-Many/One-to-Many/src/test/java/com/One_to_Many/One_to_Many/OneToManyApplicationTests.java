package com.One_to_Many.One_to_Many;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToManyApplicationTests {

	@Test
	void contextLoads() {
	}

}
